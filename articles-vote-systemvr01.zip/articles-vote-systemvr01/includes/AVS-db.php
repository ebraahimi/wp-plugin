<?php
function create_AVS_db(){

        global $WPDB,$table_prefix;

        $table_name = $table_prefix."AVS";

        $sql = " CREATE TABLE $table_name (
            voteId INT NOT NULL AUTO_INCREMENT,
            userId INT NOT NULL,
            articleId INT NOT NULL,
            user_ip VARCHAR(45) NOT NULL,
            vote_status TINYINT NOT NULL, 
            vote_value TINYINT NOT NULL,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (voteId)
        ) ENGINE = MyISAM DEFAULT CHARSET = latin1 AUTO_INCREMENT = 1" ;
        
    // Create table
    require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
    dbDelta( $sql );

}
?>