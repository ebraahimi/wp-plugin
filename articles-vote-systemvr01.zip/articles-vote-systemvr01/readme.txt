=== WordPress Plugin Implement ===

this is a test plugin for 2nd interview for find.co 
== Description ==

this is a plugin writen in OOP style made by SARA EBrAHIMI
== Installation ==

Installing "Article vote system Plugin" can be done by using the following steps:

1. Download the plugin 
1. Upload the ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
1. Activate the plugin through the 'Plugins' menu in WordPress

