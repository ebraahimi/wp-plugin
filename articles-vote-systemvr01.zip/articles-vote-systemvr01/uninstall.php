<?php
/**
 * @package Article_Vote_System/Uninstall
 */

// If plugin is not being uninstalled, exit (do nothing).
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
global $wpdb;
$table_name = $wpdb->prefix . "AVS";
$wpdb->query("DROP TABLE IF EXISTS $table_name");
