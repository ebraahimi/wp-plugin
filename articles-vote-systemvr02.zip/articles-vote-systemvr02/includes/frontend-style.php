<?php
        // add my html content 
    function add_vote_block_html_to_post_content( $content ) {
         //add my css links
        wp_enqueue_style( 'bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css', array(), '4.5.0' );
        wp_enqueue_style( 'font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), '4.7.0' );
        wp_enqueue_style( 'frontend', plugin_dir_url( __FILE__ ) .'../assets/css/frontend.css' );
    
        //add my js script
        wp_enqueue_script( 'jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js', array(), '3.6.0', true );
        wp_enqueue_script( 'bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js', array('jquery'), '4.5.0', true );
        wp_enqueue_script( 'frontend', plugin_dir_url( __FILE__ ) . '../assets/js/frontend.js', array(), '1.0', true );

        $post_id = get_the_ID();
        //render html
        $content_html = '
                <div id="custom_html_post_' . $post_id . '" class="background flex-center">
                    <div class="wallpaper flex-center">
                        <div class="env flex-center">
                            <!-- first action -->
                            <div class="container flex-between onclickActionHide">
                                <p class="fonts">Was This Article Helpful ??</p>
                                <!-- btn -->
                                <div class="flex-between btn-width">
                                    <button class="box h6 flex-around" onclick="send_data(\'YES\')">
                                        <i class="fa fa-smile-o icon"></i>
                                        <p>YES</p>
                                    </button>
                                    <button class="box h6 flex-around" onclick="send_data(\'NO\')">
                                        <i class="fa fa-frown-o icon"></i>
                                        <p>No</p>
                                    </button>
                                </div>
                            </div>

                            <!-- second action -->
                            <div class="container flex-between onclickActionShow">
                                <p class="fonts">Thank you for your feedback</p>
                                <!-- btn -->
                                <div class="flex-between btn-width">
                                    <button class="box h6 flex-around yesResult">
                                        <i class="fa fa-smile-o icon yesResultIcon"></i>
                                        <p class="yesResultPercentage"><span></span>YES</p>
                                    </button>
                                    <button class="box h6 flex-around noResult">
                                        <i class="fa fa-frown-o icon noResultIcon"></i>
                                        <p class="noResultPercentage"><span></span>NO</p>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        ';
        $content .= $content_html;
        return $content;
}
    
