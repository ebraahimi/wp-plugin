<?php
    // Add a top-level menu item
    function add_plugin_menu() {
        require_once plugin_dir_path(__FILE__) ."all-votes-table-list.php";
        // Add main pages under the top-level menu item
        add_menu_page(
            'Vote System',            // Page title
            'Vote System',          // Menu title
            'manage_options',       // Capability required to access the page
            'All-votes-settings',   // Menu slug
            'vote_plugin_settings_page', // Callback function to render the page
            'dashicons-smiley', // Icon URL or Dashicons class
            5
        );
        // Add 1st subpages under the top-level menu item
        add_submenu_page(
            'All-votes-settings',   // Parent menu slug
            'All Votes',            // Page title
            'All Votes',            // Menu title
            'manage_options',       // Capability required to access the page
            'All-votes-settings',  // Menu slug
            'vote_plugin_settings_page'// Callback function to render the page
        );
        // Add 2nd subpages under the top-level menu item
        add_submenu_page(
            'All-votes-settings',   // Parent menu slug
            'Add New',            // Page title
            'Add New',            // Menu title
            'manage_options',       // Capability required to access the page
            'vote-Add-new',  // Menu slug
            'vote_plugin_subpage_1_content' // Callback function to render the page
        );
    }

    // plugin main page content goes here
    function vote_plugin_settings_page() {
        echo '<div style="display:flex; Flex-direction: row; align-items: center; justify-content:left;">';
        echo '<h1 style="margin-right: 10px;">All Votes</h1>'.'&nbsp;&nbsp;&nbsp';
        echo '<button type="button" class="button button-primary">Create new poll</button>';
        echo '</div> </br>';
        echo '<div style="padding:0 20% 0 20%">'.table_list_show().'</div> ';
    }

    // plugin submain page content goes here
    function vote_plugin_subpage_1_content() {
        echo '<h1>Create Poll</h1>';
    }
    //render list below btn in all votes report page
    function table_list_show(){
        require_once plugin_dir_path(__FILE__) ."all-votes-table-list.php";
        $custom_list_table = new All_votes_List_Table();
        $custom_list_table->prepare_items();
        $custom_list_table->display();
    }
