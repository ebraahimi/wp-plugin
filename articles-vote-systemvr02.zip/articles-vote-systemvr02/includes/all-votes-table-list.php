<?php
/**
 * @see WP_List_Table
 */
class All_votes_List_Table extends WP_List_Table {
    public static $data;

    public function __construct() {
        parent::__construct( array(
            'singular' => 'vote', // Singular label
            'plural'   => 'votes', // Plural label
            'ajax'     => false // Whether to enable AJAX for this table or not
        ) );
        // Retrieve   data here, e.g., from the database
        $this->data = $this->fetch_data();
    }
    /**
	 * Checks the current user's permissions.
	 * @return bool
	 */
	public function ajax_user_can() {
		if ( $this->is_site_users ) {
			return current_user_can( 'manage_sites' );
		} else {
			return current_user_can( 'list_users' );
		}
	}

    // Retrieve   data from the database
    private static function fetch_data() {
        // Retrieve   data from the database here
        global $wpdb, $table_prefix;
        $table_name = $table_prefix . "AVS";
        $results = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A );
        return $results;
    }

    // Define the columns that will be displayed in the table
    public function get_columns() {
        return array(
            'voteId' => 'Vote ID',
            'userId' => 'User ID',
            'articleId' => 'Article ID',
            'user_ip' => 'User IP',
            'vote_status' => 'Vote Status',
            'vote_value' => 'Vote Value',
            'date' => 'Date'
        );
    }

    // Prepare   data for display
    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = array(); // Columns to hide
        $sortable = array(); // Columns that are sortable
    
        if (!empty($this->data)) {
            // Define the sortable columns
            $this->_column_headers = array( $columns, $hidden, $sortable );
    
            // Pagination
            $per_page = 20; // Number of items per page
            $current_page = $this->get_pagenum(); // Get the current page number
            $total_items = count( $this->data );
    
            // Slice the data to display only the current page's data
            $this->items = array_slice( $this->data, ( ( $current_page - 1 ) * $per_page ), $per_page );
    
            // Set the pagination arguments
            $this->set_pagination_args( array(
                'total_items' => $total_items, // Total number of items
                'per_page'    => $per_page, // Number of items per page
                'total_pages' => ceil( $total_items / $per_page ) // Total number of pages
            ) );
        } else {
            // If data is empty, display a message to the user
            echo 'No data available.';
        }
    }
    

    // Render the column values
    public function column_default( $item, $column_name ) {
        return isset( $item[ $column_name ] ) ? $item[ $column_name ] : '';
    }
}
