<?php
// Database connection
// global $wpdb,$table_prefix;

// // اجرای یک کوئری SQL
// $results = $wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'post' AND post_status = 'publish'" );

// $table_name = $table_prefix."AVS";

// // Check if the IP address is received
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['userIP'])) {
//     $userIP = $_POST['userIP'];
//     // Prepare and bind the SQL statement
//     $stmt = $conn->prepare("INSERT INTO $table_name (user_ip) VALUES (.$userIP.)");
//     $stmt->bind_param("s", $userIP);

//     // Respond with success
//     echo 'User IP saved successfully.';
// } else {
//     // Respond with error if the request method is not POST or IP is not received
//     http_response_code(400);
//     echo 'Error: Invalid request.';
// }
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST[ ''])) {
    
//     // Prepare and bind the SQL statement
//     $stmt = $conn->prepare("INSERT INTO user_ips (ip_address) VALUES (?)");
//     $stmt->bind_param("s", $userIP);

//     // Set parameters and execute
//     $userIP = $_POST['ip'];
//     $stmt->execute();

//     // Close statement
//     $stmt->close();

//     // Close connection
//     $conn->close();

//     // Respond with success
//     echo 'User IP saved successfully.';
// } else {
//     // Respond with error if the request method is not POST or IP is not received
//     http_response_code(400);
//     echo 'Error: Invalid request.';
// }
?>
