<?php
/*
 * Plugin Name:       Article Vote System
 * Plugin URI:        ---This is Demo
 * Description:       This is very simple vote poll 
 * Version:           1.1.0
 * Author:            Sara Ebrahimi
 * Author URI:        https://ebraahimi.net/en/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        ---
 * Text Domain:       ---
 * Domain Path:       /languages
 */

defined('ABSPATH') || exit;

require_once plugin_dir_path(__FILE__) ."includes/AVS-db.php";
require_once plugin_dir_path(__FILE__) ."includes/menus.php";
require_once plugin_dir_path(__FILE__) ."includes/frontend-data.php";
require_once plugin_dir_path(__FILE__) ."includes/frontend-style.php";

 //OOP
class Article_Vote_System{

    private static $article;

    public static function get_articles(){
        if(self::$article == NULL){
            self::$article = new self();
        }
        return self::$article;
    }

    private function __construct(){
        add_action('admin_menu','add_plugin_menu');
        // create table at activation moment
        register_activation_hook( __FILE__, 'create_AVS_db' );
		//add front end design to each article 
		add_filter( 'the_content', 'add_vote_block_html_to_post_content' );
    }
}

//get instance of obj
Article_Vote_System::get_articles();
