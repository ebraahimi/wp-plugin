jQuery(document).ready(function($) {
    //prepration on load
    jQuery('.onclickActionShow').hide();
    jQuery('.onclickActionHide').show('slow');

    // Function to send the send to the backendside
    function saveUserIP(userIP , postId , voteStatus , voteVal) {
        $.ajax({
            url: 'includes/frontend-data.php',
            type: 'POST',
            data: { 
                ip: userIP ,
                postId: postId,
                voteStatus: voteStatus,
                voteVal: voteVal,
            },
            success: function(response) {
                console.log('User IP saved successfully.');
            },
            error: function(xhr, status, error) {
                console.error('Error saving user IP:', error);
            }
        });
    }

    // Function to get the user's IP address
    function getUserIP(callback) {
        jQuery.getJSON('https://api.ipify.org?format=json', function(data) {
            var userIP = data.ip;
            callback(userIP);
        });
    }

    // Call getUserIP to get the IP and then saveUserIP to send it to the server
    getUserIP(function(ip) {
        saveUserIP(ip);
    });

})

function send_data(arg){
    if (arg === "YES"){
        //actions
        jQuery('.onclickActionHide').hide();
        jQuery('.onclickActionShow').show('slow');
        //add style to selected btn
        jQuery('.yesResult').addClass('selected');
        //desablizing btn 
        jQuery('.yesResult').prop('disabled', true);
        jQuery('.noResult').prop('disabled', true);
    }else{
        //actions
        jQuery('.onclickActionHide').hide();
        jQuery('.onclickActionShow').show('slow');
        //add style to selected btn
        jQuery('.noResult').addClass('selected');
        //desablizing btn 
        jQuery('.yesResult').prop('disabled', true);
        jQuery('.noResult').prop('disabled', true);
    }
}